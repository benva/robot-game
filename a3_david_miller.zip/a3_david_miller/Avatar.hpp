#ifndef AVATAR_H
#define AVATAR_H

#include "Robot.hpp"

class Avatar : public Robot {
private:
	
public:
};

#endif
